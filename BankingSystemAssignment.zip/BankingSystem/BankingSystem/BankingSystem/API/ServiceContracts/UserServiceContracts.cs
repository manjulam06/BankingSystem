﻿using BankingSystem.Models.User;
using Microsoft.AspNetCore.Identity;

namespace BankingSystem.API.ServiceContracts
{
    public enum ResponseResult
    {
        Success,
        Failure,
        Error,
        Exception
    }
    public class BaseResponse
    {
        public string ResponseResult { get; set; }
        public string ResponseMessage { get; set; }
    }

    public class GetAllAccountDetails : BaseResponse
    {
        public List<AccountDetail> AccountDetails { get; set; }
    }

    public class GetUserAccountDetails : BaseResponse
    {
        public AccountDetail? AccountDetail { get; set; }
    }

    public class DepositAmountRequest
    {
        public string AccountType { get; set; }
        public string AccountNumber { get; set; }
        public double Amount { get; set; }
    }

    public class DepositAmountResponse : BaseResponse
    {
        public double CurrentBalance { get; set; }
    }


    public class WithdrawAmountRequest
    {
        public string AccountType { get; set; }
        public string AccountNumber { get; set; }
        public double Amount { get; set; }
    }

    public class WithdrawAmountResponse : BaseResponse
    {
        public double CurrentBalance { get; set; }
    }

    public class OpenAccountRequest
    {
        public string AccountType { get; set; }
        public AccountHolder AccountHolder { get; set; }
    }

    public class OpenAccountResponse : BaseResponse
    {

    }

    public class CloseAccountRequest
    {
        public string AccountNumber { get; set; }
        public string UId { get; set; }
        public string AccountType { get; set; }
    }

    public class CloseAccountResponse : BaseResponse
    {

    }
}
