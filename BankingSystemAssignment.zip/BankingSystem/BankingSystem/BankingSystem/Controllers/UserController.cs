﻿using BankingSystem.API.ServiceContracts;
using BankingSystem.Models.User;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BankingSystem.Controllers
{
    public class UserController : Controller
    {
        public static List<AccountDetail> AccountDetails;

        static UserController()
        {
            AccountDetails = SeedUserAccountData();
        }

        /// <summary>
        /// GetUserAccountDetailsByUId - Method to fetch all the user's associated accounts
        /// </summary>
        /// <returns></returns>
        [HttpGet("GetUserAccountDetailsByUId/{uId}")]
        public GetAllAccountDetails GetUserAccountDetailsByUId(string uId)
        {
            if (string.IsNullOrEmpty(uId))
            {
                return new GetAllAccountDetails
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Unique Identifier cannot be null or empty"
                };
            }

            var _accountDetails = AccountDetails.Where(a => a.AccountHolder.UID == uId).ToList();

            return new GetAllAccountDetails()
            {
                ResponseResult = nameof(ResponseResult.Success),
                AccountDetails = _accountDetails
            };
        }

        [HttpGet("GetUserAccountDetails/{accountNumber}")]
        public GetUserAccountDetails GetUserAccountDetailsByAccountNumber(string accountNumber)
        {
            if (string.IsNullOrEmpty(accountNumber))
            {
                return new GetUserAccountDetails
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Account number cannot be null or empty"
                };
            }

            var _accountDetails = AccountDetails.FirstOrDefault(a => a.AccountNumber == accountNumber);

            return new GetUserAccountDetails()
            {
                ResponseResult = nameof(ResponseResult.Success),
                AccountDetail = _accountDetails
            };
        }

        [HttpPost("OpenAccount")]
        public OpenAccountResponse OpenAccount([FromBody]OpenAccountRequest request)
        {
            if (request == null)
            {
                return new OpenAccountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Request should not be null"
                };
            }

            if (string.IsNullOrEmpty(request.AccountType))
            {
                return new OpenAccountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Account Type is required"
                };
            }

            if (!Enum.IsDefined(typeof(AccountType), request.AccountType))
            {
                return new OpenAccountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = $"Invalid Account Type: {request.AccountType}"
                };
            }


            if (request.AccountHolder == null)
            {
                return new OpenAccountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Account Holder details are required"
                };
            }

            if (string.IsNullOrEmpty(request.AccountHolder.UID))
            {
                return new OpenAccountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "UId is required"
                };
            }

            if (string.IsNullOrEmpty(request.AccountHolder.FirstName))
            {
                return new OpenAccountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "First name is required"
                };
            }

            if (string.IsNullOrEmpty(request.AccountHolder.LastName))
            {
                return new OpenAccountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Last name is required"
                };
            }

            if (request.AccountHolder.CurrentAddress == null)
            {
                return new OpenAccountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Current Address is required"
                };
            }

            if (string.IsNullOrEmpty(request.AccountHolder.CurrentAddress.State))
            {
                return new OpenAccountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Current Address State is required"
                };
            }

            if (string.IsNullOrEmpty(request.AccountHolder.CurrentAddress.Street))
            {
                return new OpenAccountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Current Address Street is required"
                };
            }

            if (string.IsNullOrEmpty(request.AccountHolder.CurrentAddress.ZipCode))
            {
                return new OpenAccountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Current Address Zip code is required"
                };
            }

            if (string.IsNullOrEmpty(request.AccountHolder.CurrentAddress.City))
            {
                return new OpenAccountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Current Address City is required"
                };
            }

            var account = AccountDetails.FirstOrDefault(a =>
            string.Equals(a.AccountHolder.FirstName, request.AccountHolder.FirstName, StringComparison.OrdinalIgnoreCase)
            && string.Equals(a.AccountHolder.LastName, request.AccountHolder.LastName, StringComparison.OrdinalIgnoreCase)
            && string.Equals(a.AccountHolder.UID, request.AccountHolder.UID, StringComparison.OrdinalIgnoreCase)
            && string.Equals(a.AccountType, request.AccountType, StringComparison.OrdinalIgnoreCase));

            if (account != null)
            {
                return new OpenAccountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = $"{request.AccountType} account is already exist for customer {request.AccountHolder.FirstName}{request.AccountHolder.LastName}"
                };
            }

            var accountDetails = new AccountDetail
            {
                AccountNumber = GenerateAccountNumber(),
                AccountType = request.AccountType,
                CurrentBalance = 100,
                AccountHolder = request.AccountHolder
            };

            AccountDetails.Add(accountDetails);

            return new OpenAccountResponse
            {
                ResponseResult = nameof(ResponseResult.Success),
                ResponseMessage = $"Your account has opened successfully, your account number is {accountDetails.AccountNumber}"
            };
        }

        [HttpPost("CloseAccount")]
        public CloseAccountResponse CloseAccount([FromBody] CloseAccountRequest request)
        {
            if (request == null)
            {
                return new CloseAccountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Request should not be null"
                };
            }

            if (string.IsNullOrEmpty(request.AccountNumber))
            {
                return new CloseAccountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Account Number is required"
                };
            }

            if (string.IsNullOrEmpty(request.UId))
            {
                return new CloseAccountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "UId is required"
                };
            }

            if (string.IsNullOrEmpty(request.AccountType))
            {
                return new CloseAccountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Account Type is required"
                };
            }

            if (!Enum.IsDefined(typeof(AccountType), request.AccountType))
            {
                return new CloseAccountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = $"Invalid Account Type: {request.AccountType}"
                };
            }


            var account = AccountDetails.FirstOrDefault(a => a.AccountNumber == request.AccountNumber
            && a.AccountHolder.UID == request.UId
            && a.AccountType == request.AccountType);

            if (account == null)
            {
                return new CloseAccountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Invalid Account number or UId or Account Type"
                };
            }

            AccountDetails.Remove(account);

            return new CloseAccountResponse
            {
                ResponseResult = nameof(ResponseResult.Success),
                ResponseMessage = $"Your account with {request.AccountNumber} has closed successfully"
            };
        }

        [HttpPost("WithdrawAmount")]
        public WithdrawAmountResponse WithdrawAmount([FromBody] WithdrawAmountRequest request)
        {
            if (request == null)
            {
                return new WithdrawAmountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Request should not be null"
                };
            }

            if (request.Amount <= 0)
            {
                return new WithdrawAmountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Amount should be greater than zero"
                };
            }

            if (string.IsNullOrEmpty(request.AccountNumber))
            {
                return new WithdrawAmountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Account Number is required"
                };
            }


            if (string.IsNullOrEmpty(request.AccountType))
            {
                return new WithdrawAmountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Account Type is required"
                };
            }

            if (!Enum.IsDefined(typeof(AccountType), request.AccountType))
            {
                return new WithdrawAmountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = $"Invalid Account Type: {request.AccountType}"
                };
            }

            var account = AccountDetails.FirstOrDefault(a => a.AccountNumber == request.AccountNumber && a.AccountType == request.AccountType);

            if (account == null)
            {
                return new WithdrawAmountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Invalid Account"
                };
            }

            //Current balance should not be less or equal to 100$
            if (account.CurrentBalance < 100 || (account.CurrentBalance - request.Amount) < 100)
            {
                return new WithdrawAmountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "your account should have minimun 100$"
                };
            }

            //Withrow amount should not be greater than 90% of current balance
            if (account.CurrentBalance * 90 / 100 < request.Amount)
            {
                return new WithdrawAmountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Your are not allowed to withdrow 90% of your total balance"
                };
            }

            AccountDetails.Remove(account);
            account.CurrentBalance -= request.Amount;
            AccountDetails.Add(account);

            return new WithdrawAmountResponse
            {
                CurrentBalance = account.CurrentBalance,
                ResponseResult = nameof(ResponseResult.Success),
                ResponseMessage = $"Your current balance is ${account.CurrentBalance}"
            };
        }

        [HttpPost("DepositAmount")]
        public DepositAmountResponse DepositAmount([FromBody] DepositAmountRequest request)
        {
            if (request == null)
            {
                return new DepositAmountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Request should not be null"
                };
            }

            if (request.Amount <= 0)
            {
                return new DepositAmountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Amount should be greater than zero"
                };
            }

            if (request.Amount > 10000)
            {
                return new DepositAmountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Deposit amount should not be greater or equal to $10,000"
                };
            }

            if (string.IsNullOrEmpty(request.AccountNumber))
            {
                return new DepositAmountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Account Number is required"
                };
            }


            if (string.IsNullOrEmpty(request.AccountType))
            {
                return new DepositAmountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Account Type is required"
                };
            }

            if (!Enum.IsDefined(typeof(AccountType), request.AccountType))
            {
                return new DepositAmountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = $"Invalid Account Type: {request.AccountType}"
                };
            }

            var account = AccountDetails.FirstOrDefault(a => a.AccountNumber == request.AccountNumber && a.AccountType == request.AccountType);

            if (account == null)
            {
                return new DepositAmountResponse
                {
                    ResponseResult = nameof(ResponseResult.Error),
                    ResponseMessage = "Invalid Account"
                };
            }

            AccountDetails.Remove(account);
            account.CurrentBalance += request.Amount;
            AccountDetails.Add(account);

            return new DepositAmountResponse
            {
                CurrentBalance = account.CurrentBalance,
                ResponseResult = nameof(ResponseResult.Success),
                ResponseMessage = $"Your current balance is ${account.CurrentBalance}"
            };
        }

        private string GenerateAccountNumber()
        {
            var random = new Random();
            string accountNumber = string.Empty;
            for (int index = 0; index < 15; index++)
            {
                accountNumber = String.Concat(accountNumber, random.Next(10).ToString());
            }

            return accountNumber;
        }

        private static List<AccountDetail> SeedUserAccountData()
        {
            if (AccountDetails == null)
            {
                AccountDetails = new List<AccountDetail>
                {
                    new AccountDetail
                    {
                        AccountHolder = new AccountHolder
                        {
                            FirstName = "Anshika",
                            LastName = "Solanki",
                            UID = "1234432156788765",
                            Mobile = "9912345669",
                            CurrentAddress = new Address
                            {
                                City = "Jaipur",
                                State = "Rajasthan",
                                Street ="123 Street",
                                ZipCode ="890701"
                            }
                        },
                        AccountNumber = "123456789012345",
                        CurrentBalance = 2000,
                        AccountType = nameof(AccountType.Saving)
                    },
                    new AccountDetail
                    {
                        AccountHolder = new AccountHolder
                        {
                            FirstName = "Manjunath",
                            LastName = "M",
                            UID = "1234432156788764",
                            Mobile = "991234888",
                            CurrentAddress = new Address
                            {
                                City = "Bangalore",
                                State = "Karnataka",
                                Street ="123 Street",
                                ZipCode ="111111"
                            }
                        },
                        AccountNumber = "123456789012355",
                        CurrentBalance = 10000,
                        AccountType = nameof(AccountType.Saving)
                    }
                };
            }

            return AccountDetails;
        }
    }
}
