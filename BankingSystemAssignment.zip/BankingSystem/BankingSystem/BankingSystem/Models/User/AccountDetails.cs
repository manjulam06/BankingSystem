﻿using System.Reflection.Metadata.Ecma335;

namespace BankingSystem.Models.User
{
    public enum AccountType
    {
        Saving,
        Current
    }

    public class AccountDetail
    {
        public string AccountNumber { get; set; } = null!;
        public string AccountType { get; set; }
        public AccountHolder AccountHolder { get; set; }
        public double CurrentBalance { get; set; }
    }

    public class AccountHolder
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string UID { get; set; }
        public string Mobile { get; set; } = null!;
        public Address CurrentAddress { get; set; }
    }

    public class Address
    {
        public string City { get; set; } = null!;
        public string State { get; set; } = null!;
        public string Street { get; set; } = null!;
        public string ZipCode { get; set; } = null!;
    }


}
