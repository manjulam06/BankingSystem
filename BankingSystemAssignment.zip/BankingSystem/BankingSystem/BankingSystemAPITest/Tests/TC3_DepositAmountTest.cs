﻿using Newtonsoft.Json;
using NUnit.Framework.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using static BankingSystemAPITest.Models.Response.APIResponse;

namespace BankingSystemAPITest.Tests
{
    public class TC3_DepositAmountTest
    {
        [Test]
        public void DepositAmountSuccessfully()
        {
            //Act
            string jsondata = "{\"AccountType\":\"Saving\",\"AccountNumber\":\"123456789012355\",\"Amount\":\"1000\"}";
            var restClient = new RestClientHelper();
            var response = restClient.DepositAmount(jsondata).GetAwaiter().GetResult();
            WithdrawAmountResponse deposit = JsonConvert.DeserializeObject<WithdrawAmountResponse>(response.Content);

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.IsTrue(deposit.ResponseMessage.Contains("Your current balance is "),"Response is invalid");
            Assert.NotZero(deposit.CurrentBalance);
        }

        [Test]
        public void DepositAmount_Show_Validation_Message_For_ZeroDeposit()
        {
            //Act
            string jsondata = "{\"AccountType\":\"Saving\",\"AccountNumber\":\"123456789012355\",\"Amount\":\"0\"}";
            var restClient = new RestClientHelper();
            var response = restClient.DepositAmount(jsondata).GetAwaiter().GetResult();
            WithdrawAmountResponse deposit = JsonConvert.DeserializeObject<WithdrawAmountResponse>(response.Content);

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.AreEqual("Amount should be greater than zero",deposit.ResponseMessage);
        }

        [Test]
        public void DepositAmount_Show_Validation_Message_For_DepostAmountGreaterThan10000()
        {
            //Act
            string jsondata = "{\"AccountType\":\"Saving\",\"AccountNumber\":\"123456789012355\",\"Amount\":\"11000\"}";
            var restClient = new RestClientHelper();
            var response = restClient.DepositAmount(jsondata).GetAwaiter().GetResult();
            string resp = response.Content.ToString();
            WithdrawAmountResponse deposit = JsonConvert.DeserializeObject<WithdrawAmountResponse>(response.Content);

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.AreEqual("Deposit amount should not be greater or equal to $10,000", deposit.ResponseMessage);
        }

        [Test]
        public void DepositAmount_Show_Validation_Message_For_NoAccountNumber()
        {
            //Act
            string jsondata = "{\"AccountType\":\"Saving\",\"Amount\":\"10000\"}";
            var restClient = new RestClientHelper();
            var response = restClient.DepositAmount(jsondata).GetAwaiter().GetResult();
            WithdrawAmountResponse deposit = JsonConvert.DeserializeObject<WithdrawAmountResponse>(response.Content);

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.AreEqual("Account Number is required", deposit.ResponseMessage);
        }

        [Test]
        public void DepositAmount_Show_Validation_Message_For_NoAccountType()
        {
            //Act
            string jsondata = "{\"AccountNumber\":\"123456789012355\",\"Amount\":\"10000\"}";
            var restClient = new RestClientHelper();
            var response = restClient.DepositAmount(jsondata).GetAwaiter().GetResult();
            WithdrawAmountResponse deposit = JsonConvert.DeserializeObject<WithdrawAmountResponse>(response.Content);

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.AreEqual("Account Type is required", deposit.ResponseMessage);
        }

        [Test]
        public void DepositAmount_Show_Validation_Message_For_InvalidAccountType()
        {
            //Act
            string jsondata = "{\"AccountType\":\"NoType\",\"AccountNumber\":\"123456789012355\",\"Amount\":\"10000\"}";
            var restClient = new RestClientHelper();
            var response = restClient.DepositAmount(jsondata).GetAwaiter().GetResult();

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.IsTrue(response.Content.Contains("Invalid Account Type:"),"response is not as expected");
        }

        [Test]
        public void DepositAmount_Show_Validation_Message_For_InvalidAccountNumber()
        {
            //Act
            string jsondata = "{\"AccountType\":\"Saving\",\"AccountNumber\":\"129012355\",\"Amount\":\"10000\"}";
            var restClient = new RestClientHelper();
            var response = restClient.DepositAmount(jsondata).GetAwaiter().GetResult();
            WithdrawAmountResponse deposit = JsonConvert.DeserializeObject<WithdrawAmountResponse>(response.Content);

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.AreEqual("Invalid Account", deposit.ResponseMessage);
        }



    }
}
