﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BankingSystemAPITest.Models.Response.APIResponse;

namespace BankingSystemAPITest.Tests
{
    public class TC2_GetUserAccountDetailsByUIdTest
    {
        [Test] 
        public void GetAccountByValidUID()
        {
            string Uid = "1234432156788764";
            var restClient = new RestClientHelper();
            var response = restClient.GetUserAccountDetailsByUId(Uid).GetAwaiter().GetResult();
            GetAllAccountDetails account = JsonConvert.DeserializeObject<GetAllAccountDetails>(response.Content);

            Assert.IsNotNull(account.AccountDetails);
            Assert.AreEqual("Success", account.ResponseResult);
            Assert.IsNull(account.ResponseMessage);
            Assert.IsTrue(account.AccountDetails.All(x => x.AccountHolder.UID == Uid));
        }

        [Test]
        public void GetAccountByInvalidUID()
        {
            string Uid = "123456765432345";
            var restClient = new RestClientHelper();
            var response = restClient.GetUserAccountDetailsByUId(Uid).GetAwaiter().GetResult();
            GetAllAccountDetails account = JsonConvert.DeserializeObject<GetAllAccountDetails>(response.Content);

            Assert.IsNotNull(account.AccountDetails);
            Assert.AreEqual("Success", account.ResponseResult);
            Assert.IsNull(account.ResponseMessage);
            Assert.Zero(account.AccountDetails.Count);
        }
    }
}
