﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BankingSystemAPITest.Models.Response.APIResponse;

namespace BankingSystemAPITest.Tests
{
    public class TC1_GetUserAccountDetailsByAccountNumberTest
    {
        [Test] 
        public void GetAccountByValidAccountnumber()
        {
            string accountNumber = "123456789012355";
            var restClient = new RestClientHelper();
            var response = restClient.GetUserAccountDetails(accountNumber).GetAwaiter().GetResult();
            GetUserAccountDetails account = JsonConvert.DeserializeObject<GetUserAccountDetails>(response.Content);

            Assert.IsNotNull(account.AccountDetail);
            Assert.AreEqual("Success", account.ResponseResult);
            Assert.IsNull(account.ResponseMessage);
            Assert.IsTrue(account.AccountDetail.AccountNumber == accountNumber);
        }

        [Test]
        public void GetAccountByInvalidAccoountNumber()
        {
            string accountNumber = "234565434";
            var restClient = new RestClientHelper();
            var response = restClient.GetUserAccountDetails(accountNumber).GetAwaiter().GetResult();
            GetUserAccountDetails account = JsonConvert.DeserializeObject<GetUserAccountDetails>(response.Content);

            Assert.IsNull(account.AccountDetail);
            Assert.AreEqual("Success", account.ResponseResult);
            Assert.IsNull(account.ResponseMessage);
        }
    }
}
