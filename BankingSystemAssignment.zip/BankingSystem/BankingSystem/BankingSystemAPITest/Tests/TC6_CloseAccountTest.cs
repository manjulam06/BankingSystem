﻿using Microsoft.VisualBasic;
using Newtonsoft.Json;
using NUnit.Framework.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using static BankingSystemAPITest.Models.Response.APIResponse;

namespace BankingSystemAPITest.Tests
{
    public class TC6_CloseAccountTest
    {
        [Test]
        public void CloseAccountSuccessfully()
        {
            //Act
            string jsondata = "{\"AccountType\":\"Saving\",\"AccountNumber\":\"123456789012345\",\"UId\":\"1234432156788765\"}";
            var restClient = new RestClientHelper();
            var response = restClient.CloseAccount(jsondata).GetAwaiter().GetResult();
            CloseAccountResponse closeAccount = JsonConvert.DeserializeObject<CloseAccountResponse>(response.Content);

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.AreEqual("Success", closeAccount.ResponseResult);
            Assert.AreEqual("Your account with 123456789012345 has closed successfully", closeAccount.ResponseMessage);
        }

        [Test]
        public void CloseAccount_Show_Validation_Message_For_NoAccountNumber()
        {
            //Act
            string jsondata = "{\"AccountType\":\"Saving\",\"UId\":\"1234432156788765\"}";
            var restClient = new RestClientHelper();
            var response = restClient.CloseAccount(jsondata).GetAwaiter().GetResult();
            CloseAccountResponse closeAccount = JsonConvert.DeserializeObject<CloseAccountResponse>(response.Content);

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.AreEqual("Error", closeAccount.ResponseResult);
            Assert.AreEqual("Account Number is required", closeAccount.ResponseMessage);
        }

        [Test]
        public void CloseAccount_Show_Validation_Message_For_NoUid()
        {
            //Act
            string jsondata = "{\"AccountType\":\"Saving\",\"AccountNumber\":\"123456789012345\"}";
            var restClient = new RestClientHelper();
            var response = restClient.CloseAccount(jsondata).GetAwaiter().GetResult();
            CloseAccountResponse closeAccount = JsonConvert.DeserializeObject<CloseAccountResponse>(response.Content);

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.AreEqual("Error", closeAccount.ResponseResult);
            Assert.AreEqual("UId is required", closeAccount.ResponseMessage);
        }

        [Test]
        public void CloseAccount_Show_Validation_Message_For_NoAccountType()
        {
            //Act
            string jsondata = "{\"AccountNumber\":\"123456789012345\",\"UId\":\"1234432156788765\"}";
            var restClient = new RestClientHelper();
            var response = restClient.CloseAccount(jsondata).GetAwaiter().GetResult();
            CloseAccountResponse closeAccount = JsonConvert.DeserializeObject<CloseAccountResponse>(response.Content);

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.AreEqual("Error", closeAccount.ResponseResult);
            Assert.AreEqual("Account Type is required", closeAccount.ResponseMessage);
        }

        [Test]
        public void CloseAccount_Show_Validation_Message_For_InvalidAccountType()
        {
            //Act
            string jsondata = "{\"AccountType\":\"NoType\",\"AccountNumber\":\"123456789012345\",\"UId\":\"1234432156788765\"}";
            var restClient = new RestClientHelper();
            var response = restClient.CloseAccount(jsondata).GetAwaiter().GetResult();
            CloseAccountResponse closeAccount = JsonConvert.DeserializeObject<CloseAccountResponse>(response.Content);

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.AreEqual("Error", closeAccount.ResponseResult);
            Assert.AreEqual("Invalid Account Type: NoType", closeAccount.ResponseMessage);
        }

        [Test]
        public void CloseAccount_Show_Validation_Message_For_InvalidAccountNumber()
        {
            //Act
            string jsondata = "{\"AccountType\":\"Saving\",\"AccountNumber\":\"129012355\",\"UId\":\"1234432156788765\"}";
            var restClient = new RestClientHelper();
            var response = restClient.CloseAccount(jsondata).GetAwaiter().GetResult();
            CloseAccountResponse closeAccount = JsonConvert.DeserializeObject<CloseAccountResponse>(response.Content);

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.AreEqual("Error", closeAccount.ResponseResult);
            Assert.AreEqual("Invalid Account number or UId or Account Type", closeAccount.ResponseMessage);
        }

        [Test]
        public void CloseAccount_Show_Validation_Message_For_InvalidUid()
        {
            //Act
            string jsondata = "{\"AccountType\":\"Saving\",\"AccountNumber\":\"129012355\",\"UId\":\"4535565432456\"}";
            var restClient = new RestClientHelper();
            var response = restClient.CloseAccount(jsondata).GetAwaiter().GetResult();
            CloseAccountResponse closeAccount = JsonConvert.DeserializeObject<CloseAccountResponse>(response.Content);

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.AreEqual("Error", closeAccount.ResponseResult);
            Assert.AreEqual("Invalid Account number or UId or Account Type", closeAccount.ResponseMessage);
        }



    }
}
