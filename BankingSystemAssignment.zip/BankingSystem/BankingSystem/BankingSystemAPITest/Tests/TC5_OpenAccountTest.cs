﻿using NUnit.Framework.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static BankingSystemAPITest.Models.Request.APIRequest;

namespace BankingSystemAPITest.Tests
{
    public class TC5_OpenAccountTest
    {

        [Test]
        [Order(1)]
        public void OpenSavingsAccount_Successfully()
        {
            //Arrange
            string jsondata = "{\"AccountType\":\"Saving\",\"AccountHolder\":{\"FirstName\":\"Manjula\",\"LastName\":\"M\",\"UID\":\"1234567890987\",\"Mobile\":\"8946995406\",\"CurrentAddress\":{\"City\":\"Test\",\"State\":\"Test\",\"Street\":\"Test\",\"ZipCode\":\"Test\"}}}";

            //ACT
            var restClient = new RestClientHelper();
            var response = restClient.OpenAccount(jsondata).GetAwaiter().GetResult();

            //Assert
            Assert.IsNotNull(response);
            TestContext.Progress.WriteLine(response.Content.ToString());
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.IsTrue(response.Content.Contains("Your account has opened successfully, your account number is"), "Response does not contain success message");
        }

        [Test]
        public void OpenSavingsAccount_Show_Validation_Message_For_DuplicateAccount()
        {
            //Arrange
            string jsondata = "{\"AccountType\":\"Saving\",\"AccountHolder\":{\"FirstName\":\"Manjula\",\"LastName\":\"M\",\"UID\":\"1234567890987\",\"Mobile\":\"8946995406\",\"CurrentAddress\":{\"City\":\"Test\",\"State\":\"Test\",\"Street\":\"Test\",\"ZipCode\":\"Test\"}}}";

            //ACT
            var restClient = new RestClientHelper();
            var response = restClient.OpenAccount(jsondata).GetAwaiter().GetResult();

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.IsTrue(response.Content.Contains("account is already exist for customer"), "Response does not contain success message");
        }

        [Test]
        public void OpenCurrentAccount_Successfully()
        {
            //Arrange
            string jsondata = "{\"AccountType\":\"Current\",\"AccountHolder\":{\"FirstName\":\"Manjula\",\"LastName\":\"M\",\"UID\":\"1234567890987\",\"Mobile\":\"8946995406\",\"CurrentAddress\":{\"City\":\"Test\",\"State\":\"Test\",\"Street\":\"Test\",\"ZipCode\":\"Test\"}}}";

            //ACT
            var restClient = new RestClientHelper();
            var response = restClient.OpenAccount(jsondata).GetAwaiter().GetResult();

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            TestContext.Progress.WriteLine(response.Content.ToString());
            Assert.IsTrue(response.Content.Contains("Your account has opened successfully, your account number is"), "Response does not contain success message");
        }




        [Test]
        public void OpenSavingsAccount_Show_Validation_Message_For_AccountType()
        {
            //Arrange
            string jsondata = "{\"AccountHolder\":{\"FirstName\":\"Manjula\",\"LastName\":\"M\",\"UID\":\"1234567890987\",\"Mobile\":\"8946995406\",\"CurrentAddress\":{\"City\":\"Test\",\"State\":\"Test\",\"Street\":\"Test\",\"ZipCode\":\"Test\"}}}";

            //ACT
            var restClient = new RestClientHelper();
            var response = restClient.OpenAccount(jsondata).GetAwaiter().GetResult();

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.IsTrue(response.Content.Contains("Account Type is required"), "Resquest object is not valid");
        }

        [Test]
        public void OpenSavingsAccount_Show_Validation_Message_For_FirstName()
        {
            //Arrange
            string jsondata = "{\"AccountType\":\"Saving\",\"AccountHolder\":{\"LastName\":\"M\",\"UID\":\"1234567890987\",\"Mobile\":\"8946995406\",\"CurrentAddress\":{\"City\":\"Test\",\"State\":\"Test\",\"Street\":\"Test\",\"ZipCode\":\"Test\"}}}";
            //ACT
            var restClient = new RestClientHelper();
            var response = restClient.OpenAccount(jsondata).GetAwaiter().GetResult();

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.IsTrue(response.Content.Contains("First name is required"), "Resquest object is not valid");
        }

        [Test]
        public void OpenSavingsAccount_Show_Validation_Message_For_LastName()
        {
            //Arrange
            string jsondata = "{\"AccountType\":\"Saving\",\"AccountHolder\":{\"FirstName\":\"Manjula\",\"UID\":\"1234567890987\",\"Mobile\":\"8946995406\",\"CurrentAddress\":{\"City\":\"Test\",\"State\":\"Test\",\"Street\":\"Test\",\"ZipCode\":\"Test\"}}}";
            //ACT
            var restClient = new RestClientHelper();
            var response = restClient.OpenAccount(jsondata).GetAwaiter().GetResult();

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.IsTrue(response.Content.Contains("Last name is required"), "Resquest object is not valid");
        }

        [Test]
        public void OpenSavingsAccount_Show_Validation_Message_For_UID()
        {
            //Arrange
            string jsondata = "{\"AccountType\":\"Saving\",\"AccountHolder\":{\"FirstName\":\"Manjula\",\"LastName\":\"M\",\"Mobile\":\"8946995406\",\"CurrentAddress\":{\"City\":\"Test\",\"State\":\"Test\",\"Street\":\"Test\",\"ZipCode\":\"Test\"}}}";

            //ACT
            var restClient = new RestClientHelper();
            var response = restClient.OpenAccount(jsondata).GetAwaiter().GetResult();

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.IsTrue(response.Content.Contains("UId is required"), "Resquest object is not valid");
        }
        [Test]
        public void OpenSavingsAccount_Show_Validation_Message_For_CurrentAddress()
        {
            //Arrange
            string jsondata = "{\"AccountType\":\"Saving\",\"AccountHolder\":{\"FirstName\":\"Manjula\",\"LastName\":\"M\",\"UID\":\"1234567890987\",\"Mobile\":\"8946995406\"}}";

            //ACT
            var restClient = new RestClientHelper();
            var response = restClient.OpenAccount(jsondata).GetAwaiter().GetResult();

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.IsTrue(response.Content.Contains("Current Address is required"), "Response does not contain success message");
        }

        [Test]
        public void OpenSavingsAccount_Show_Validation_Message_For_State()
        {
            //Arrange
            string jsondata = "{\"AccountType\":\"Saving\",\"AccountHolder\":{\"FirstName\":\"Manjula\",\"LastName\":\"M\",\"UID\":\"1234567890987\",\"Mobile\":\"8946995406\",\"CurrentAddress\":{\"City\":\"Test\",\"Street\":\"Test\",\"ZipCode\":\"Test\"}}}";

            //ACT
            var restClient = new RestClientHelper();
            var response = restClient.OpenAccount(jsondata).GetAwaiter().GetResult();

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.IsTrue(response.Content.Contains("Current Address State is required"), "Response does not contain success message");
        }

        [Test]
        public void OpenSavingsAccount_Show_Validation_Message_For_Street()
        {
            //Arrange
            string jsondata = "{\"AccountType\":\"Saving\",\"AccountHolder\":{\"FirstName\":\"Manjula\",\"LastName\":\"M\",\"UID\":\"1234567890987\",\"Mobile\":\"8946995406\",\"CurrentAddress\":{\"City\":\"Test\",\"State\":\"Test\",\"ZipCode\":\"Test\"}}}";

            //ACT
            var restClient = new RestClientHelper();
            var response = restClient.OpenAccount(jsondata).GetAwaiter().GetResult();

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.IsTrue(response.Content.Contains("Current Address Street is required"), "Response does not contain success message");
        }

        [Test]
        public void OpenSavingsAccount_Show_Validation_Message_For_City()
        {
            //Arrange
            string jsondata = "{\"AccountType\":\"Saving\",\"AccountHolder\":{\"FirstName\":\"Manjula\",\"LastName\":\"M\",\"UID\":\"1234567890987\",\"Mobile\":\"8946995406\",\"CurrentAddress\":{\"State\":\"Test\",\"Street\":\"Test\",\"ZipCode\":\"Test\"}}}";

            //ACT
            var restClient = new RestClientHelper();
            var response = restClient.OpenAccount(jsondata).GetAwaiter().GetResult();

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.IsTrue(response.Content.Contains("Current Address City is required"), "Response does not contain success message");
        }

        [Test]
        public void OpenSavingsAccount_Show_Validation_Message_For_ZipCode()
        {
            //Arrange
            string jsondata = "{\"AccountType\":\"Saving\",\"AccountHolder\":{\"FirstName\":\"Manjula\",\"LastName\":\"M\",\"UID\":\"1234567890987\",\"Mobile\":\"8946995406\",\"CurrentAddress\":{\"City\":\"Test\",\"State\":\"Test\",\"Street\":\"Test\"}}}";

            //ACT
            var restClient = new RestClientHelper();
            var response = restClient.OpenAccount(jsondata).GetAwaiter().GetResult();

            //Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.IsTrue(response.Content.Contains("Current Address Zip code is required"), "Response does not contain success message");
        }

       
    }
}
