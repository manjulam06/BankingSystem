﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingSystemAPITest
{
    public interface IAPIClient
    {
        Task<RestResponse> OpenAccount(string payload);

        Task<RestResponse> CloseAccount(string payload);

        Task<RestResponse> GetUserAccountDetailsByUId(string UId);

        Task<RestResponse> GetUserAccountDetails(string accountNumber);

        Task<RestResponse> DepositAmount(string payload);

        Task<RestResponse> WithdrawAmount(string payload);
    }
}
