﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingSystemAPITest
{
    public class EndPoints
    {
        public static readonly string OpenAccount = "OpenAccount";
        public static readonly string GetUserAccountDetails = "GetUserAccountDetails/{accountNumber}";
        public static readonly string GetUserAccountDetailsByUId = "GetUserAccountDetailsByUId/{uid}";
        public static readonly string WithdrawAmount = "WithdrawAmount";
        public static readonly string DepositAmount = "DepositAmount";
        public static readonly string CloseAccount = "CloseAccount";
    }
}
