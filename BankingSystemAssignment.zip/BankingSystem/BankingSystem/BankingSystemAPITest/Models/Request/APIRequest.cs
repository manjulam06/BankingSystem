﻿using BankingSystemAPITest.Models.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingSystemAPITest.Models.Request
{
    public class APIRequest
    {
        public class DepositAmountRequest
        {
            public string AccountType { get; set; }
            public string AccountNumber { get; set; }
            public double Amount { get; set; }
        }


        public class WithdrawAmountRequest
        {
            public string AccountType { get; set; }
            public string AccountNumber { get; set; }
            public double Amount { get; set; }
        }



        public class OpenAccountRequest
        {
            public string AccountType { get; set; }
            public AccountHolder AccountHolder { get; set; }
        }



        public class CloseAccountRequest
        {
            public string AccountNumber { get; set; }
            public string UId { get; set; }
            public string AccountType { get; set; }
        }


    }
}
