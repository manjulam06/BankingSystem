﻿using BankingSystemAPITest.Models.Common;


namespace BankingSystemAPITest.Models.Response
{
    public class APIResponse
    {
        public class BaseResponse
        {
            [Newtonsoft.Json.JsonProperty("responseResult")]
            public string ResponseResult { get; set; }
            [Newtonsoft.Json.JsonProperty("responseMessage")]
            public string ResponseMessage { get; set; }
        }

        public class GetAllAccountDetails : BaseResponse
        {
            public List<AccountDetail> AccountDetails { get; set; }
        }

        public class GetUserAccountDetails : BaseResponse
        {
            public AccountDetail? AccountDetail { get; set; }
        }

        public class WithdrawAmountResponse : BaseResponse
        {
            [Newtonsoft.Json.JsonProperty("currentBalance")]
            public double CurrentBalance { get; set; }
        }

        public class OpenAccountResponse : BaseResponse
        {

        }

        public class CloseAccountResponse : BaseResponse
        {

        }

    }
}
