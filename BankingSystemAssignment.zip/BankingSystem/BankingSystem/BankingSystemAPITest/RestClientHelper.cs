﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace BankingSystemAPITest
{
    public class RestClientHelper : IAPIClient , IDisposable
    {
        readonly RestClient _client;
        readonly string baseUrl = "https://localhost:44378/";

        public RestClientHelper()
        {
            var options = new RestClientOptions(baseUrl);
            _client = new RestClient(options);
        }
        public void Dispose()
        {
            _client?.Dispose(); 
            GC.SuppressFinalize(this);
        }

        public async Task<RestResponse> CloseAccount(string payload)
        {
            var request = new RestRequest(EndPoints.CloseAccount, Method.Post);
            request.AddBody(payload);
            return await _client.ExecuteAsync(request);
        }

        public async Task<RestResponse> DepositAmount(string payload)
        {
            var request = new RestRequest(EndPoints.DepositAmount, Method.Post);
            request.AddBody(payload);
            return await _client.ExecuteAsync(request);
        }


        public async Task<RestResponse> WithdrawAmount(string payload)
        {
            var request = new RestRequest(EndPoints.WithdrawAmount, Method.Post);
            request.AddBody(payload);
            return await _client.ExecuteAsync(request);
        }

        public async Task<RestResponse> GetUserAccountDetails(string accountNumber) 
        {
            var request = new RestRequest(EndPoints.GetUserAccountDetails, Method.Get);
            request.AddUrlSegment("accountNumber", accountNumber);
           // request.AddParameter("accountNumber", accountNumber);
            return await _client.ExecuteAsync(request);
        }

        public async Task<RestResponse> GetUserAccountDetailsByUId(string UId)
        {
            var request = new RestRequest(EndPoints.GetUserAccountDetailsByUId, Method.Get);
            request.AddUrlSegment("uid", UId);
            return await _client.ExecuteAsync(request);
        }

        public async Task<RestResponse> OpenAccount(string payload)
        {
            var request = new RestRequest(EndPoints.OpenAccount, Method.Post);
            request.AddBody(payload, ContentType.Json);
            return await _client.ExecuteAsync(request);
        }
    }
}
